#!/bin/sh

set -e

OS_NAME=$(uname -s)
JB_PRODUCTS="idea clion phpstorm goland pycharm webstorm webide rider datagrip rubymine dataspell aqua rustrover gateway jetbrains_client jetbrainsclient studio devecostudio"
BASE_PATH="/Users/kian/Library/Application Support/JetBrains"
PLIST_PATH="${HOME}/Library/LaunchAgents/jetbrains.vmoptions.plist"

rm -rf "$BASE_PATH/config-jetbrains"
rm -rf "$BASE_PATH/plugins-jetbrains"
rm -rf "$BASE_PATH/vmoptions"
rm -rf "$BASE_PATH/ja-netfilter.jar"
rm -rf "${PLIST_PATH}"
echo "卸载完成"
