https://www.quanxiaoha.com/dev-tools/

cd scripts
chmod +x *

sudo ./install-mac.sh
